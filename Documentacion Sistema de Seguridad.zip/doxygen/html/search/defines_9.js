var searchData=
[
  ['servo_5fpin_0',['SERVO_PIN',['../_sistema_seguridad__final_8ino.html#a5218f89aa292654356a48989319aafb1',1,'SistemaSeguridad_final.ino']]],
  ['ss_5fpin_1',['SS_PIN',['../_sistema_seguridad__final_8ino.html#a86fac98c9b4c98a3e50fc45440878391',1,'SistemaSeguridad_final.ino']]]
];
