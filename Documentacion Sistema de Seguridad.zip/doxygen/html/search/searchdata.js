var indexSectionsWithContent =
{
  0: "abcdefghiklmnprstuv",
  1: "u",
  2: "s",
  3: "acdefghilmprsv",
  4: "abcdefghiklmnprstuv",
  5: "egr",
  6: "abcgimr",
  7: "bdefghlmrstu",
  8: "cdsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Enumeraciones",
  6: "Valores de enumeraciones",
  7: "defines",
  8: "Páginas"
};

