var searchData=
[
  ['max_5fusuarios_0',['MAX_USUARIOS',['../_sistema_seguridad__final_8ino.html#a0145df6bb6266e199e863ed5a9b0ac79',1,'SistemaSeguridad_final.ino']]],
  ['mic_5fpin_1',['MIC_PIN',['../_sistema_seguridad__final_8ino.html#af39ccba2dfff8548b1d0066abcf7c413',1,'SistemaSeguridad_final.ino']]]
];
