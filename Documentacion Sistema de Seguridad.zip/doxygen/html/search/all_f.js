var searchData=
[
  ['sensores_0',['CAPA UNIFICADA DE SENSORES',['../_sistema_seguridad__final_8ino.html#autotoc_md1',1,'']]],
  ['sensoresvalidos_1',['sensoresValidos',['../_sistema_seguridad__final_8ino.html#a4ac216c4af29bef70e26e1bf94893339',1,'SistemaSeguridad_final.ino']]],
  ['servo_2',['servo',['../_sistema_seguridad__final_8ino.html#a79efceea669fb85a732c30f47cf7e59c',1,'SistemaSeguridad_final.ino']]],
  ['servo_5fpin_3',['SERVO_PIN',['../_sistema_seguridad__final_8ino.html#a5218f89aa292654356a48989319aafb1',1,'SistemaSeguridad_final.ino']]],
  ['servoabierto_4',['servoAbierto',['../_sistema_seguridad__final_8ino.html#a53df7d8be971dfb43f9564ab95b3e9a6',1,'SistemaSeguridad_final.ino']]],
  ['setcolor_5',['setColor',['../_sistema_seguridad__final_8ino.html#a0401e16405b1b77498de5af016e0e8fe',1,'SistemaSeguridad_final.ino']]],
  ['setcoloroff_6',['setColorOff',['../_sistema_seguridad__final_8ino.html#a9c3193cbbc8d3f56d841fc5a8b68480e',1,'SistemaSeguridad_final.ino']]],
  ['setup_7',['setup',['../_sistema_seguridad__final_8ino.html#a4fc01d736fe50cf5b977f755b675f11d',1,'SistemaSeguridad_final.ino']]],
  ['sistemaseguridad_5ffinal_2eino_8',['SistemaSeguridad_final.ino',['../_sistema_seguridad__final_8ino.html',1,'']]],
  ['ss_5fpin_9',['SS_PIN',['../_sistema_seguridad__final_8ino.html#a86fac98c9b4c98a3e50fc45440878391',1,'SistemaSeguridad_final.ino']]]
];
