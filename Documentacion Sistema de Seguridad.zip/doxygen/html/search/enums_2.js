var searchData=
[
  ['regstate_0',['RegState',['../_sistema_seguridad__final_8ino.html#ae967697349c14143e968165aa02d7ac5',1,'SistemaSeguridad_final.ino']]],
  ['rol_1',['Rol',['../_sistema_seguridad__final_8ino.html#ae77c345092166d1349677587f2329d95',1,'SistemaSeguridad_final.ino']]]
];
