var searchData=
[
  ['horariopermitido_0',['horarioPermitido',['../_sistema_seguridad__final_8ino.html#ad6268cfdbfc91f00af8db5ff30c6fbf4',1,'SistemaSeguridad_final.ino']]]
];
