var searchData=
[
  ['reg_5fclave_0',['REG_CLAVE',['../_sistema_seguridad__final_8ino.html#ae967697349c14143e968165aa02d7ac5ace94d563a68403765fead0b41f8456b2',1,'SistemaSeguridad_final.ino']]],
  ['reg_5fdone_1',['REG_DONE',['../_sistema_seguridad__final_8ino.html#ae967697349c14143e968165aa02d7ac5a26350040ebe0468d45ce663846d04f31',1,'SistemaSeguridad_final.ino']]],
  ['reg_5fhora_5ffin_2',['REG_HORA_FIN',['../_sistema_seguridad__final_8ino.html#ae967697349c14143e968165aa02d7ac5a5e02c0bfa3e336c481a358110478afbf',1,'SistemaSeguridad_final.ino']]],
  ['reg_5fhora_5fini_3',['REG_HORA_INI',['../_sistema_seguridad__final_8ino.html#ae967697349c14143e968165aa02d7ac5a8e20d674a42249f316f568c3833ce34a',1,'SistemaSeguridad_final.ino']]],
  ['reg_5fidle_4',['REG_IDLE',['../_sistema_seguridad__final_8ino.html#ae967697349c14143e968165aa02d7ac5aedff175ec7fa8ad4d888517c31e5ca5e',1,'SistemaSeguridad_final.ino']]],
  ['reg_5fnombre_5',['REG_NOMBRE',['../_sistema_seguridad__final_8ino.html#ae967697349c14143e968165aa02d7ac5a7664093b5a83b0c98089f304cba0c8ba',1,'SistemaSeguridad_final.ino']]],
  ['reg_5frfid_6',['REG_RFID',['../_sistema_seguridad__final_8ino.html#ae967697349c14143e968165aa02d7ac5a5f0e2c4a62c951bc29fc1b780c4ca77b',1,'SistemaSeguridad_final.ino']]],
  ['reg_5frol_7',['REG_ROL',['../_sistema_seguridad__final_8ino.html#ae967697349c14143e968165aa02d7ac5a2a9ce2d31d7faf9895974e751292c249',1,'SistemaSeguridad_final.ino']]],
  ['rol_5fcoordinador_8',['ROL_COORDINADOR',['../_sistema_seguridad__final_8ino.html#ae77c345092166d1349677587f2329d95a39fc80e3e889d75ab9e89c9a7819a48a',1,'SistemaSeguridad_final.ino']]],
  ['rol_5fgerente_9',['ROL_GERENTE',['../_sistema_seguridad__final_8ino.html#ae77c345092166d1349677587f2329d95a88d9519aff05291bfbedc9716c315240',1,'SistemaSeguridad_final.ino']]],
  ['rol_5foperario_10',['ROL_OPERARIO',['../_sistema_seguridad__final_8ino.html#ae77c345092166d1349677587f2329d95a8b877e7ddd96999bda3aeb1e39abc7c1',1,'SistemaSeguridad_final.ino']]],
  ['rol_5fseguridad_11',['ROL_SEGURIDAD',['../_sistema_seguridad__final_8ino.html#ae77c345092166d1349677587f2329d95add1c897ca641aa2be703011df331b577',1,'SistemaSeguridad_final.ino']]]
];
