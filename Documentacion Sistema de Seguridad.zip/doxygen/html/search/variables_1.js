var searchData=
[
  ['bloqueoauthpendiente_0',['bloqueoAuthPendiente',['../_sistema_seguridad__final_8ino.html#a778f36b378e9289aa3c4c0031ef85410',1,'SistemaSeguridad_final.ino']]],
  ['bloqueomostro_1',['bloqueoMostro',['../_sistema_seguridad__final_8ino.html#aa7bb161532628248e9c681cf323c63b5',1,'SistemaSeguridad_final.ino']]]
];
