var struct_usuario =
[
    [ "clave", "struct_usuario.html#aeab745e3cc314dea9002aa1912c08125", null ],
    [ "claveAnt", "struct_usuario.html#aaa5990c54349d030048291e70339aa7f", null ],
    [ "horaFin", "struct_usuario.html#aa6e912b161cf2eb4fe798f8a5fc58434", null ],
    [ "horaIni", "struct_usuario.html#a5633fc12c3a27b473b951a9b2320d601", null ],
    [ "nombre", "struct_usuario.html#a88aac989a86c5f7a1011a59b248b3a6d", null ],
    [ "rol", "struct_usuario.html#a32632f64dbbeb690018c8d85277255a5", null ],
    [ "tag", "struct_usuario.html#a20f7481a536539cc7df7705c0ddf1f6d", null ],
    [ "usosClave", "struct_usuario.html#ad5dd46a6057cce69546db2c40eee201b", null ]
];